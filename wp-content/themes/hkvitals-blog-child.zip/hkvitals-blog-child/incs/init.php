<?php
include "ajax.php";
include "theme-functions.php";
include "shortcodes.php";
