---
title: Genesis Onboarding
layout: layouts/base.njk
permalink: developer-features/onboarding/index.html
minVersion: Genesis 2.9.0+ and WordPress 5.0.0+
tags: docs
---

Visit the new <a href="{{ '/theme-setup/' | url }}">one-click theme setup</a> page to learn about Genesis theme setup.
